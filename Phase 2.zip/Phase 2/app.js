const express = require('express'); 
const app = express();
require('dotenv').config();
const { auth, requiresAuth } = require('express-openid-connect');


app.use(
  auth({
    authRequired: false,
    auth0Logout: true,
    issuerBaseURL: process.env.ISSUER_BASE_URL,
    baseURL: process.env.BASE_URL,
    clientID: process.env.CLIENT_ID,
    secret: process.env.SECRET,
    idpLogout: true,
  })
);

// Anyone can access the homepage
app.get('/',function(req,res) {
  res.sendFile(__dirname + '/pages/index.html');
});

// Signup Page
app.get('/signup.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/signup.html');
});

// Index Page
app.get('/index.html',function(req,res) {
  res.sendFile(__dirname + '/pages/index.html');
});

// Property Page
app.get('/property.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/property.html');
});

// Manage Page
app.get('/manage.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/manage.html');
});

// Workspace Page
app.get('/workspace.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/workspace.html');
});

// Owner Page
app.get('/owner.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/owner.html');
});

// Coworker Page
app.get('/search.html', requiresAuth(), (req, res) => {
  res.sendFile(__dirname + '/pages/search.html');
});

const port = process.env.PORT || 3000;
app.listen(port, () =>{
    console.log(`listening on port ${port}`);
});